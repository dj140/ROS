#rikirobot

rikirobot is an robotic project that aims to provide students, developers, and researchers a low-cost platform in creating new exciting applications on top of ROS.

